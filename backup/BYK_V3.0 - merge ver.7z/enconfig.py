# encoding =utf-8
module_gaindata = r"data/temptate_gain.csv"
module_lostdata = r"data/temptate_lost.csv"
module_week_gaindata = r"data/temptate_week_gain.csv"
module_week_lostdata = r"data/temptate_week_lost.csv"


def enconfig(month, ups=0):
    pass


if __name__ == "__main__":
    pass
