# encoding =utf-8
import csv
import time


# 导入文件
# 接受一个csv文件的目录，返回列表。


def fast_import(file: str):
    try:
        with open(file, "r")as f:
            csv_reader = csv.reader(f)
            return list(csv_reader)
    except FileNotFoundError:
        raise FileNotFoundError


# 导出文件
# 接受一个列表和输出文件目录，输出csv文件
def fast_export(lst, file):
    with open(file, "w+", newline="")as f:
        csv_writer = csv.writer(f)
        csv_writer.writerows(lst)
    return file


# 字符串时间格式转时间元组对象(年月日时)
def str2tuple(stime: str):
    # return int(stime[0:4]), int(stime[4:6]), int(stime[6:8]), int(stime[8:10]), 0, 0, 0, 0, 0
    return time.strptime(stime, "%Y%m%d%H")


# unix时间转字符串时间格式
def unix2str(ftime: float): return time.strftime("%Y%m%d%H", time.localtime(ftime))


def str2unix(stime: str): return int(time.mktime(str2tuple(stime)))


def halfdayago(stime): return unix2str(str2unix(stime) - 3600 * 12)


def onedayago(stime): return unix2str(str2unix(stime) - 3600 * 24)


def oneweekago(stime): return unix2str(str2unix(stime) - 3600 * 24 * 7)


def list2dictuple(lst):
    """给出列表可被字典化的元组格式。只要前4列。"""
    return lst[0], lst[1:4]


def time_str_list(start: str, end: str, interval=12):
    """
    根据起止时间生成字符串时间的列表，例如：
    time_str_list("2020040611","2020040723")=="
        ["2020040611","2020040623","2020040711","2020040723"]
    :param start: 开始时间
    :param end: 结束时间
    :param interval: 间隔（小时），默认为12。
    :return: 包含两端，每隔interval个小时的时间列表。
    """
    # 字符串时间转unix时间
    u_start, u_end = str2unix(start), str2unix(end)
    # 生成时间列表
    time_list = range(u_start, u_end + 1, interval * 3600)
    # 转换回字符串格式
    ret = list(map(unix2str, time_list))
    return ret


def str2filename(time_prefix: str, file_type: str, dir_prefix: str = "", ext: str = ".csv"):
    """
    给定字符串，构建相应的fan或者cha的csv文件名

    time_prefix: 时间前缀，数字字符串。
    filename: 目标的文件类型（fan或者cha，或cha_server）。
    dir: 默认的文件定位地址，默认为本文件目录。
    ext: 文件后缀名。默认为csv。
    """
    filename = {"fan": fr"\fans\fans{time_prefix}",
                "cha": fr"\cha\cha{time_prefix}",
                "cha_server": fr"\cha_server\cha{time_prefix}-1",
                "cha_month": fr"\cha_month\cha{time_prefix}"}
    # 由 filename 给出相应合适文件路径和文件名
    return dir_prefix + filename[file_type] + ext


enable_log_True = True
enable_warn_True = True


def log(slog):
    if enable_log_True:
        print(slog)


def warn(slog):
    if enable_warn_True:
        print(slog)


def smart_choice_time():
    """
    给出当前时间点上最后生成文件的时间
    :return:最后生成文件的时间
    """
    stime_now = unix2str(time.time())
    date_now = stime_now[:-2]
    hour_now = int(stime_now[-2:])

    ret = date_now + "11"
    if hour_now < 6:
        ret = onedayago(ret)
    elif hour_now < 18:
        ret = halfdayago(ret)
    return ret


def replaceAll(s: str, rule: dict):
    """约等于MMA的/.功能。"""
    for keys in rule:
        s = s.replace(keys, rule[keys])
    return s
