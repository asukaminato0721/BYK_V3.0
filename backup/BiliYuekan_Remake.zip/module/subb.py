# encoding=utf-8

from time import process_time

if __name__ == "__main__":
    from libs import fast_import, fast_export, onedayago, halfdayago, time_str_list
    from libs import log
    from libs import str2filename, list2dictuple

else:
    from module.libs import fast_import, fast_export, onedayago, halfdayago, time_str_list
    from module.libs import log
    from module.libs import str2filename, list2dictuple

# 默认值
month_start = "2020040123"
month_end = "2020043023"
day_finish = "2020050123"
# tmpdir = r"..\temp" if __name__=="__main__" else r"\temp"
tmpdir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\temp"


def smart_minus(left, right):
    """
    智能减法，尝试转数字然后相减。
    能减给结果，不能减返回左边的。
    """
    try:
        return int(left) - int(right)
    except ValueError:
        return left


def diff(key, new, old):
    """
    给出两个一维表的做差结果。如果存在不能做差的部分，给出新的
    :param old: 旧一维表
    :param new: 新一维表
    :param key: 关键字
    :return: 做差结果，前面跟上关键字。
    """
    try:
        ret = [key] + [smart_minus(data[0], data[1]) for data in zip(new, old)]
    except TypeError:
        pass
    return ret


# 整个二维表做差，返回做差结果
def Cha(newList: list, oldList: list) -> list:
    """
    两个二维表整体做差。第一行第一列不动,按旧的来
    :param oldList:旧二维表
    :param newList:新二维表
    :return: 做差结果，不能做差的按新的来（理论上不会）
    """
    # log(f"Cha({oldList[1][0]},{newList[1][0]}等)")
    # 字典化

    oldDict, newDict = [dict(map(list2dictuple, lst)) for lst in [oldList[1:], newList[1:]]]
    # 释放内存，这一步gc开销有点大
    # del oldList, newList
    ret = []
    # 新表有而旧表没有的，应当视为旧表是零。
    # （否则新表第二天会发现么的数据）
    for mid in newDict.keys():

        # TODO 但也同样存在旧表里没有而新表有的情况。这时候旧表应该被设置为零
        if mid not in oldDict:
            continue
        # 生成返回的对应行数据
        # 如果一天前数据不存在，需要生成和今天数据列数相等的全零表。比较长就单独写出来了
        old_line_data = oldDict.get(mid, [0] * len(newDict[mid]))
        line = diff(mid, newDict[mid], old_line_data)
        ret.append(line)
    return ret


def fandata(date: str):
    """
    给定日期，提取对应的fan文件内容。
    :param date:
    :return:给定日期的fan文件的数据
    """
    ret = fast_import(str2filename(date, "fan", tmpdir))
    return ret


def subb(day_start_time: str, day_finish_time: str, target_dir: str = tmpdir):
    """
    从给定开始时间，每半天计算一个差文件。

    :param day_start_time: 开始时间（年月日时）
    :param day_finish_time: 全部结束时间（年月日时）
    :param target_dir: 目标文件夹，默认值由 subb.py 中的tempDir给定。
    """
    log(f"subb({day_start_time},{day_finish_time}, '{target_dir})'")

    # 初始数据
    datalist = [fandata(onedayago(day_start_time)), fandata(halfdayago(day_start_time))]
    # 遍历
    time_list = time_str_list(day_start_time, day_finish_time)
    for i in time_list:
        # 丢进去一个新的（预备动作）
        # TODO 如果已有差文件，不再重复劳动
        datalist.append(fandata(i))

        # 丢进去的和前一天的做差
        # （核心步骤）
        export = Cha(datalist[-1], datalist[-3])

        # 输出文件（首尾）
        export_dir = str2filename(i, "cha", target_dir)
        fast_export(export, export_dir)
        log(f"export file at {export_dir}")


if __name__ == "__main__":
    # subb(month_start, day_finish, tmpdir)
    a = subb("2020050123", "2020061023")
    print(process_time())
