# encoding =utf-8

"""
爬取头像。
"""
import json
import re

import cv2
import numpy as np
import requests
from PIL import Image

if __name__ == "__main__":
    from libs import log, fast_import, fast_export
else:
    from module.libs import log, fast_import, fast_export

# 好颜色文件的路径
good_color_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\data\好颜色.csv"
good_color = dict(fast_import(good_color_dir))

# 注销改名文件的路径
logoff_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\data\logoff.json"
logoff_pattern = "账号[已]?注销[0-9]*|[0-9]+_bili"
with open(logoff_dir) as f:
    logoff = json.load(f)

# 输出目标路径
export_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\amine"

# api地址
api_url = "https://api.bilibili.com/x/web-interface/card?mid="

# blacklist
blacklist = ["吴织亚切大忽悠"]


def download_header(uid, face_link):
    # 由于cv2对webp支持有问题，改用PIL。
    # 已经测试对于 webp gif 普通jpg 头像都没有问题
    # 下载图片有时候可能是网络不好会导致报错，所以加重连
    retry = 0
    face_response=None
    while retry < 5:
        try:
            face_response = requests.get(face_link)
            break
        except:
            retry += 1
    else:
        # 重连5次建议换网络环境再说
        raise requests.exceptions.ConnectionError
    # 没找到怎么从内存直接读取图片方式，先下到tmp里
    with open("tmp", "wb") as f:
        f.write(face_response.content)
    # 读取图片
    # img = cv2.imread("tmp")
    img_PIL = Image.open("tmp")
    # 调整大小
    # exp = cv2.resize(img, (240, 240))
    exp = img_PIL.resize((240, 240))
    # 输出
    # cv2.imwrite(export_dir + fr"\{uid}.png", exp)
    exp.save(export_dir + fr"\{uid}.png", "PNG")
    # 计算颜色，如果在好颜色里面就不用算了
    if uid in good_color:
        return good_color[uid]
    else:
        # 读取平均颜色用PIL反而不好做，所以还是用cv2
        img_cv2 = cv2.imread(export_dir + fr"\{uid}.png")
        channels = cv2.mean(img_cv2)
        # llc选择让这个颜色更黑10%，我也不知道为啥
        # 反正照抄就是了，咱也看不懂
        darker = lambda color: color * 0.9 + 255 * 0.1
        darker_RGB = [int(darker(channel)) for channel in channels[0:3]]
        ret = "0x" + (hex(darker_RGB[0])[2:] + hex(darker_RGB[1])[2:] + hex(darker_RGB[2])[2:]).upper()
        return ret


def crawl(up_data):
    # 信息拆分
    uid = up_data[0]
    print(f"正在处理{uid}")
    udata = up_data[1:]
    # 获取信息
    url = api_url + uid
    response = requests.get(url)
    content = json.loads(response.content)
    # up名称
    name = content["data"]["card"]["name"]

    if uid in logoff:
        name += f"（原：{logoff[uid]}）"
    elif name in blacklist:
        name = ""
    elif re.search(logoff_pattern, name) is not None:
        print(f"新增注销帐号：{name}，用户uid:{uid}")
    # up 爬取头像并且计算颜色
    face_link = content["data"]["card"]["face"]
    color = download_header(uid, face_link)
    ret = np.array([uid] + [name] + [color] + udata)
    return ret


def headpic(inter_data):
    """
    对插值后的数据爬取up头像，计算指定颜色。
    :param inter_data: 插值后的数据，二维表格。
    :return: 最后需要的总表“data.csv”
    """
    head = inter_data[0]
    ret_head = [head[0]] + ["", ""] + head[1:]
    # 每行是一个up的数据
    ret_body = [crawl(up_data) for up_data in inter_data[1:]]

    log("由插值文件生成data.csv")
    # TODO 对于每个up，在2,3列插入up名称与计算得到的颜色
    # TODO 根据“好颜色.csv”提前选择颜色

    # 用的是numpy的转置，所以会得到numpy的数组对象，转化为list比较好
    ret = np.transpose([ret_head] + ret_body).tolist()
    return ret


if __name__ == "__main__":
    yuedu_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\temp\data-yuedu.csv"
    inter = fast_import(yuedu_dir)
    data_final = headpic(inter)
    fast_export(data_final, r"..\amine\data.csv")
    # webp头像
    # crawl(["686127", "other"])
    # gif 头像
    # crawl(["261036",""])
    # jpg 头像
    # crawl(["261037", ""])
