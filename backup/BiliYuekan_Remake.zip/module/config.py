# encoding =utf-8

if __name__ == "__main__":
    from libs import fast_import, fast_export, log
else:
    from module.libs import fast_import, fast_export, log


def enconfig(module_data: list, month_: int, up_count: int = 0):
    """
    生成config文件。
    :param month_: 几月份，0视为周榜
    :param up_count: up人数。为零则是视为涨粉。
    :param module_data:模板文件数据列表
    :return: None
    """
    month_dict = {0: "一周", 1: "一月", 2: "二月", 3: "三月", 4: "四月", 5: "五月", 6: "六月", 7: "七月", 8: "八月",
                  9: "九月", 10: "十月", 11: "十一月", 12: "十二月"}
    # 月份/星期数据转中文
    month = month_dict[month_]
    log(f"正在生成 config 文件信息。时间：{month} 人数：{up_count if up_count != 0 else '涨粉'}")

    cfg = module_data
    if up_count == 0:
        # 说明是涨粉
        cfg[1] = [fr"'本文件为 {month} 涨粉榜配置文件！'"]
        cfg[39][1] = "月度净涨粉"
    else:
        # 是掉粉，那么事情就会比较多
        cfg[39][1] = "月度净掉粉"
        cfg[1] = [f"本文件为 {month} 掉粉榜配置文件！本月上榜up人数共有 {up_count} 人！"]
        # 对焦排名
        cfg[75][0] = cfg[75][1] = up_count
        # 窗口位置对齐
        cfg[21][0] = str(int(1010 - 49.5 * up_count))
        cfg[52][0] = str(int(-70 - 49.5 * up_count))
    fast_export(cfg, "amine/config.csv")
    log("config文件生成成功。")


if __name__ == "__main__":
    fan_mode = "lost"
    # fan_mode="gain"
    if fan_mode == "gain":
        enconfig(fast_import(r"../data/temptate_gain.csv"), 5)
    else:
        enconfig(fast_import(r"../data/temptate_lost.csv"), 2, 200)
