# encoding =utf-8
import json
import time
from calendar import monthrange

if __name__ == "__main__":
    from libs import halfdayago, oneweekago
else:
    from module.libs import halfdayago, smart_choice_time, oneweekago


def import_config(config_dir):
    with open(config_dir, "r") as f:
        # 有时候文件空的，json解析器会报错，给一个空的东西。
        try:
            return json.load(f)
        except json.decoder.JSONDecodeError:
            return {}


# 选择月榜/周榜工作模式
def import_workmode(config):
    duration_type = input("选择持续时间：周榜=0/月榜=对应月份 \n ")
    if duration_type in "0123456789101112":
        config["month"] = int(duration_type)
    elif input("无效输入。默认按照上次选择继续，按q退出") == "q":
        exit()
    return config


def smart_month_head_tail(year, month):
    # 月份不足时，前面补 0
    month_s = ("0" if month < 10 else "") + str(month)
    month_initial = str(year) + month_s + "0111"
    month_start = halfdayago(month_initial)
    month_end = str(year) + month_s + str(monthrange(year, month)[1]) + "23"
    return month_start, month_end


# 输入月份与终止日信息
def import_month(config):
    """
    得到月份信息。
    命令行手工输入目标月份。
    :return:指定月份开始时间，指定月份结束时间，当前最后一个有效时间。
    """
    month = config["month"]
    # 一月算的是去年的
    year = time.localtime()[0] - (1 if time.localtime()[1] == 1 else 0)
    # 计算这个月的头尾。
    month_start, month_end = smart_month_head_tail(year, month)
    # 计算月份后要进行到哪一天。
    end_day = smart_choice_time()
    temp = input(f"智能选择结束日期为{end_day},回车确认。")
    if temp != "":
        end_day = temp
    # 信息录入
    config["month_dates"] = {}
    config["month_dates"]["month_start"] = month_start
    config["month_dates"]["month_end"] = month_end
    config["month_dates"]["end_day"] = end_day
    return config, month_start, end_day, month_end


# 得到周榜起止信息
def import_week(config):
    """
    得到周榜的起止时间信息。
    :return:一周开始时间，一周结束时间
    """
    week_end = smart_choice_time()
    week_start = oneweekago(week_end)
    # 信息录入
    config["week_dates"] = {}
    config["week_dates"]["week_start"] = week_start
    config["week_dates"]["week_end"] = week_end
    return config, week_start, week_end, None


def smart_week_or_month_import():
    global config
    start, end, month_end = import_week if config["month"] == 0 else import_month
    return start, end, month_end


# 选择涨掉粉模式
def import_fanmode(config):
    fan_type = input("选择：默认=0/涨粉=1/掉粉=2 \n ")
    if fan_type == "0":
        pass
    elif fan_type == "1":
        config["fan_type"] = "gain"
        config["top_count"] = 30
    elif fan_type == "2":
        config["fan_type"] = "lost"
        config["top_count"] = -30
    elif input("无效输入。默认按照上次选择继续，按q退出") == "q":
        exit()
    return config


def export_config(config, config_dir):
    with open(config_dir, "w") as f:
        json.dump(config, f)
