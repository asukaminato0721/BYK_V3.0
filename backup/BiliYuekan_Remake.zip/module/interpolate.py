# encoding =utf-8
from cmath import tanh
from functools import reduce

# from libs import fast_import
from scipy.interpolate import interp1d


def flatter(num: float, down: int, up: int, 宽容度: int = (1 / tanh(1)).real):
    """
    修正目标来防止出现太大的范围波动。
    在宽容度为1的情况下，输入被严格的限制在给定范围之中。
    :param 宽容度: 允许最后的值在多大程度上超出范围。
    :param num: 待修正的数
    :param target_range: 限制的修正范围，含有两个数的一个区间
    :return:
    """
    miu = (down + up) / 2
    sigma = 宽容度 * (down - up) / 2

    # 除以零错误。
    if sigma == 0:
        return miu

    num_std = (num - miu) / sigma
    ret_std = tanh(num_std).real
    ret = ret_std * sigma + miu
    # ret.real
    try:
        return int(ret.real)
    except:
        return 0


def interpolate(line, fan_mode="gain"):
    # 导入数据为字符串，空数据要置零
    data = []
    for _ in line[1:-1]:
        try:
            data.append(int(_) if _ != "" else 0)
        except (ValueError, TypeError):
            data.append(0)

    x_cood = range(len(data))
    interpoltor = interp1d(x_cood, data, kind="cubic")
    # 目标横坐标，每个参数向后插值，变为5个,但最后一个点不参与。
    target_list = [_ / 5 for _ in range(len(data[:-1]) * 5)]
    pre_ret = []
    for __ in target_list:
        try:
            num, down, up = int(interpoltor(__)), data[int(__)], data[int(__) + 1]
        except ValueError:
            break
        value = flatter(num, down, up)
        pre_ret.append(value)
    # mid + 插值数据 + 最后一天数据重复5次 + 月度数据重复10次
    if fan_mode == "gain":
        ret_data = pre_ret + [data[-1]] * 5 + [line[-1]] * 10
    else:
        ret_data = [0 if i > 0 else int(i) for i in (pre_ret + [data[-1]] * 5 + [line[-1]] * 5)]
    ret = [line[0]] + ret_data
    return ret


def general(data, fan_mode="gain"):
    head = data[0]
    body = data[1:]
    #  mid + 表头其它行各重复5次
    ret_head = [head[0]] + reduce(lambda x, y: x + y, [[_] * 5 for _ in head[1:]])
    ret_body = [interpolate(_, fan_mode) for _ in body]
    ret = [ret_head] + ret_body
    return ret


if __name__ == "__main__":
    # line = [352637817, 4408, 8281, 8281, 17124, 17124, 9145, 9145, 4525, 4525, 7947, 7947, 4761, 4761, 4763, 4763,
    # 3999, 3999, 4194, 4194, 3289, 3289, 3375, 3375, 3251, 3251, 3245, 3245, 2933, 2933, 2454, 2454, 2574, 2574,
    # 2308, 2308, 2440, 2440, 2739, 2739, 2527, 2527, 2884, 2884, 2499, 2499, 2301, 2301, 2610, 2610, 2676, 2676,
    # 2371, 2371, 2334, 2334, 2510, 2510, 1462, 1462, 2192, 2192, 2582, 2582, 2068, 2068, 2315, 2315, 2495, 2495,
    # 1841, 1841, 4772, 4772, 3742, 3742, 243834]
    # ret = interpolate(line)
    # dat = fast_import(r"..\temp\data-yuedu.csv")
    # general(dat)
    pass
