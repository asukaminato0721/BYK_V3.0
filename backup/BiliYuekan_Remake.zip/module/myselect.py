# encoding =utf-8

# 默认从一个文件中选择（含倒数）前多少名的up
if __name__ == "__main__":
    from libs import log, time_str_list, fast_import, str2filename
else:
    from module.libs import log, time_str_list, fast_import, str2filename

max_up_choose_count_30 = 30


def get_month_file(month_start: str, month_end: str):
    """
    对每日累加求和计算月度值，生成文件。
    :param month_start: 月度开始时间，应当为上月最后一天23时
    :param month_end: 月度结束时间，应当为本月最后一天23时
    :return:
    """
    # TODO 月度做差求值
    # 不是不准备写！
    # 只是咕咕咕了！
    return


def give_top(cha_data: str, num: int = max_up_choose_count_30):
    """
    给定文件的数据，选择 UP 主，并且输出 ups.csv。
    :param cha_data:给定的做差文件。
    :param num: 选择粉丝变化最高的多少个，负数为倒序。
    :return: 选中up的集合。
    """
    # log(f"从文件中数据挑选up cha_data={cha_data[1]}等{len(cha_data)}行, num={num}")
    # 对数据第一项以后进行排序，比较对象为数据行第二项的整数格式。如果为正数则倒序
    try:
        sorted_data = sorted(cha_data[1:], key=lambda _: int(_[1]), reverse=num > 0)
    except ValueError:
        # 服务器版本的cha文件多数据，应该用第四列，第二列是up名称，第三列是当前粉丝数量
        # 理论上应该都用服务器版本，但是目前改起来麻烦，准备等暑假二度重写。
        # 主要原因是这个版本一开始对于需要什么并不清楚，是真的从零开始。
        sorted_data = sorted(cha_data[1:], key=lambda _: int(_[3]), reverse=num > 0)
    lines = sorted_data[:abs(num)]

    # warn("give_top 还没有写好！")

    ups = set([_[0] for _ in lines])
    return ups


def select_from_files(start: str, end: str, max_up_choose_count: int = 30, cha_mode="cha"):
    """
    选择排名前列的up。每个数据点选择人数

    :param cha_mode: 判断一下是不是用服务器数据
    :param max_up_choose_count: 从一个文件中选择前多少名的up，负数表示倒序选择。
    :param end: 结束时间
    :param start:开始时间
    :return:挑选到的up列表
    """
    log(f"正在从文件中挑选up start={start}, end={end}, max_up_choose_count={max_up_choose_count}")
    # warn("select_from_files 还没有写好！")
    ups = set()
    for _ in time_str_list(start, end):
        abs_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\temp"
        file_data = fast_import(str2filename(_, cha_mode, dir_prefix=abs_dir))
        ups |= give_top(file_data, num=max_up_choose_count)
        # ups |= give_top(fast_import(str2filename(_, "cha",)))

    return ups


if __name__ == "__main__":
    ups = select_from_files("2020033123", "2020043023", 30)
    # ups=give_top(fast_import("../temp/cha/cha2020050323.csv"), -30)
    print(sorted(ups))
