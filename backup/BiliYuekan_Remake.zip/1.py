# encoding =utf-8
"""
做差相关函数。
共81行。
"""
import csv
import json
import os
import re
from os import listdir
from os.path import isfile


# from library.file import stime2filename, fast_export, fast_import
# from library.time_process import onedayago, halfdayago, time_str_list


def fast_import(file_name: str, ext="csv"):
    """
    导入文件。
    csv -> 嵌套列表
    json -> 字典

    :thisday ext: 解码方式
    :thisday file_name: 导入文件名
    :return: 文件内容。
    """
    try:
        with open(file_name, "r")as f:
            if ext == "csv":
                ret = list(csv.reader(f))
            elif ext == "json":
                ret = json.load(f)
            else:
                raise KeyError(f"未知文件格式：{ext}")
            return ret
    except FileNotFoundError:
        raise FileNotFoundError(f"文件不存在：{file_name}")
    except KeyError:
        raise KeyError(f"未知文件格式：{ext}")
    except json.decoder.JSONDecodeError:
        # 有时候文件会被莫名清空，解析器会出错，给一个空的就行啦
        return {}


def fast_export(data, file_name, ext="csv"):
    """
    接受数据和输出文件目录，输出csv或json文件

    :thisday ext: 文件格式
    :thisday data: ext like [[line],[line]]
    :thisday file_name:
    :return: file_name
    """
    with open(file_name, "w+", newline="")as f:
        if ext == "csv":
            csv.writer(f).writerows(data)
        elif ext == "json":
            json.dump(data, f)
    return file_name


def stime2filename(file_time: str, file_type: str, dir_prefix: str = "", ext: str = ".csv"):
    """
    给定字符串格式时间，构建相应的csv文件名。
    stime2filename(2020070411,"fan") -> fans\fans2020070411.csv

    file_time: 时间前缀，数字字符串。
    file_type: 目标的文件类型（fan，cha，或cha_server）。
    config_dir: 默认的文件定位地址，默认为本文件目录。
    ext: 文件后缀名。默认为csv。
    """
    if file_type == "fan":
        # 自动搜索文件名，代码逻辑从calcha.py 改进
        fan_dir = dir_prefix + "fans\\"
        is_legal = lambda f: isfile(fan_dir + f) and re.match(rf"^fans{file_time}.*\.csv", f)
        legal_files = [f for f in listdir(fan_dir) if is_legal(f)]
        if not legal_files:
            # 找不到文件不再返回零而是直接抛异常
            raise FileNotFoundError(dir_prefix + f"fans{file_time}*.csv not exist.")
        file2size_dict = {f: os.stat(fan_dir + f).st_size for f in legal_files}
        ret = max(file2size_dict, key=file2size_dict.get)
        # 小文件也视作异常
        min_allowed_file_size = 1024
        if file2size_dict[ret] < min_allowed_file_size:
            raise FileNotFoundError
        return fan_dir + ret
    # 其它情况按照之前的逻辑处理
    filename = {"fan_raw": f"fans{file_time}",
                "cha": r"\cha\cha{file_time}",
                "cha_server": fr"\cha_server\cha{file_time}-1"}
    return dir_prefix + filename[file_type] + ext


def str2tuple(stime: str):
    """字符串时间转为元组时间"""
    return time.strptime(stime, "%Y%m%d%H")


def unix2str(ftime: float):
    """unix时间转字符串时间"""
    return time.strftime("%Y%m%d%H", time.localtime(ftime))


def str2unix(stime: str):
    """字符串时间转unix时间"""
    tupletime = str2tuple(stime)
    ret = int(time.mktime(tupletime))
    return ret


halfdayago = lambda stime: unix2str(str2unix(stime) - 3600 * 12)
onedayago = lambda stime: unix2str(str2unix(stime) - 3600 * 24)


def time_str_list(t_start: str, t_end: str, interval=12):
    """
    根据起止时间,间隔生成字符串时间的列表

    :param t_start: 开始时间
    :param t_end: 结束时间
    :param interval: 间隔（小时），默认为12。
    :return: 包含两端，每隔 interval 个小时的时间列表。
    示例：
    >>> time_str_list('2020040611',"2020040723")
    ['2020040611', '2020040623', '2020040711', '2020040723']
    """
    # 字符串时间转unix时间
    u_start, u_end = str2unix(t_start), str2unix(t_end)
    # 生成时间列表
    time_list = range(u_start, u_end + 1, interval * 3600)
    # 转换回字符串格式
    ret = [unix2str(_) for _ in time_list]
    return ret


def fan_dict_data(fan_name: str, target_dir):
    """
    给出指定文件名的fan文件数据。
    """
    datalist = fast_import(stime2filename(fan_name, "fan", target_dir))
    ret = {_[0]: _[1:] for _ in datalist[1:]}
    return ret


def line_diff(key_, new, old, is_halfday: bool):
    """
    单行做差。

    :param key_: 主键
    :param new: 新表
    :param old: 旧表
    :param is_halfday: 是否是半天的，如果是的话结果翻倍。
    :return: 做差结果
    """
    ret_head = [int(key_)]  # 确保后面排序的时候是按照数字排序的
    ret_udata = [new[3], new[0]]
    ret_fans = [(int(_[1]) - int(_[0])) * (2 if is_halfday else 1) for _ in zip(old[:3], new[:3])]
    ret_other = [(int(_[1]) - int(_[0])) * (2 if is_halfday else 1) for _ in zip(old[4:9], new[4:9])]
    ret = ret_head + ret_udata + ret_fans + [0] + ret_other
    return ret


def cha(thisday: dict, oneDago: dict, halfDago: dict):
    """
    对 thisday 的数据进行做差。默认与 onedayago 做差，
    如onedayago无数据，与 halfdayago 做差并且数据乘二。
    如两个数据点都没有数据，认为是新入站用户，前一天数据认为是零。

    :param thisday:当前数据
    :param oneDago:半天前数据
    :param halfDago:，一天前数据
    """
    ret = []
    for mid in thisday.keys():
        new = thisday[mid]
        old = oneDago.get(mid, halfDago.get(mid, [0] * len(new)))
        line = line_diff(mid, new, old, old == halfDago.get(mid))
        ret.append(line)
    ret.sort()
    return ret


def diff(t_start, t_end, target_dir):
    """
    给定起止时间，每半天计算一个差文件

    :thisday t_start: 开始时间
    :thisday t_end: 结束时间
    :thisday target_dir: 输出路径
    :return:
    """
    print(f"正在做差：\n\t起始时间：{t_start}\n\t终止时间：{t_end}\n\t输出目录：{target_dir}")
    # 初始数据
    datalist = [fan_dict_data(onedayago(t_start), target_dir), fan_dict_data(halfdayago(t_start), target_dir)]
    # 遍历
    time_list = time_str_list(t_start, t_end)
    for i_time in time_list:
        datalist.append(fan_dict_data(i_time, target_dir))
        # 表头，主要是为了兼容性考虑
        export_head = fast_import(stime2filename(i_time, "fan", target_dir))[0][:10]
        export_head.insert(1, "name")
        export_head.insert(2, stime2filename(i_time, "fan_raw", ext=""))
        # 剩下部分
        export_body = cha(datalist[-1], datalist[-3], datalist[-2])
        export = [export_head] + export_body
        export_dir = stime2filename(i_time, "cha_server", target_dir)
        fast_export(export, export_dir)
        print(f"export file at {export_dir}")


def smart_choice_time(time_=None):
    """
    给出当前时间点上最后生成文件的时间
    :return:最后生成文件的时间
    """
    if time_ is None:
        # 当前时间
        u_now = time.time()
    else:
        u_now = str2unix(time_)
    # 前推 4 小时，任何4小时前没有开始的数据都应该没出来
    process_time = 3600 * 4
    # 偏置 3 小时 测试结果别问我为啥
    phase = 3600 * 3
    #  周期 12 小时
    cycle = 3600 * 12
    allowed = u_now - process_time - phase
    # 去掉尾数
    u_format = allowed // cycle * cycle
    u_ret = u_format + phase
    # 转字符格式输出
    ret = unix2str(u_ret)
    return ret


def single_day_diff(i_time=smart_choice_time(), target_dir=""):
    # 文件头
    export_head = fast_import(stime2filename(i_time, "fan", target_dir))[0][:10]
    export_head.insert(1, "name")
    export_head.insert(2, stime2filename(i_time, "fan_raw", ext=""))
    # 剩下部分
    export_body = cha(fan_dict_data(i_time, target_dir),
                      fan_dict_data(halfdayago(i_time), target_dir),
                      fan_dict_data(onedayago(i_time), target_dir))
    export = [export_head] + export_body
    export_dir = stime2filename(i_time, "cha_server", target_dir)
    fast_export(export, export_dir)
    print(f"export file at {export_dir}")


if __name__ == "__main__":
    diff("2020063023", "2020070123", r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake\temp""\\")

    import time

    print(time.process_time())
