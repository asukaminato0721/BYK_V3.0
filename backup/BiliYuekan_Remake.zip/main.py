# encoding =utf-8
enable_debug = False

import time

from module.config import enconfig
from module.dailydata import days_data
from module.fdata import export_fdata
from module.headpic import headpic
from module.interpolate import general
from module.libs import fast_export, str2filename, fast_import, log
from module.myimport import import_workmode, import_month, import_week, import_fanmode, import_config, export_config
from module.myselect import select_from_files, get_month_file, give_top
# from module.subb import subb
from module.subb import subb

default_abslute_dir = r"D:\OneDrive\LiWorkshop\BiliYuekan_Remake"
config_dir = default_abslute_dir + r"\data\config.json"

# enable_debug = True

if __name__ == "__main__":
    # 载入配置文件
    config = import_config(config_dir)

    # 选择涨粉
    config = import_fanmode(config)
    fan_mode = config["fan_type"]

    # 选择周榜/月榜模式，并且选择月份
    config = import_workmode(config)
    month = config["month"]
    duration = "week" if month == 0 else "month"

    # 分情况取得起止信息。
    config, start, end, month_end = import_week(config) if config["month"] == 0 else import_month(config)

    # 以下已经取得了起止信息，准备做差。
    config["cha"] = input("是否做差？0=要/1=已有/2=用服务器数据")
    if config["cha"] == "0":
        subb(start, end)

    # 挑选变化最多的up。
    if config["cha"] != "2":
        ups = select_from_files(start, end, config["top_count"])
    else:
        ups = select_from_files(start, end, config["top_count"], "cha_server")
    if config["fan_type"] == "month":
        # 累加求和计算月度信息
        month_data = get_month_file("test01", "test02")
        fast_export(month_data, str2filename(config["month"], "cha_month"))
        month_ups = give_top(month_data, config["top_count"])
        ups = ups | month_ups
    fast_export([list(map(int, ups))], r"temp\ups.csv")
    # with open(r"temp\ups.csv", "w")as f:
    #     for i in ups:
    #         f.write(i)

    # 根据 ups 生成 fdata.csv
    if input("是否跳过从服务器寻找数据？") != "1" and enable_debug:
        log("生成fdata.csv")
        if fan_mode == "gain" and duration == "month":
            year = time.localtime()[0] - (1 if time.localtime()[1] == 1 else 0)
            # 输出 fdata 下个月的内容也要收录，否则不好看。
            yearmonth = str(year) + ("0" if month < 10 else "") + str(month)
            yearnextmonth = str(year + 1 if month == 12 else 0) + ("0" if month < 10 else "") + str(
                1 + 0 if month == 12 else month)
            export_fdata(ups, [yearmonth])
        log("生成成功")

    # 生成data文件，应该是一天一行
    log("生成data_raw.csv")
    data_raw = days_data(start, month_end, end, ups, fan_mode=fan_mode, is_server=config["cha"] == "2")
    fast_export(data_raw, r"temp\data-raw.csv")
    # warn("这部分还没写\n")

    # 插值，先转置变成一人一行。
    log("插值生成data.csv")
    # data_raw = fast_import(r"temp\data-raw.csv")
    inter = general(data_raw, fan_mode)
    fast_export(inter, "temp\\data-yuedu.csv")
    # warn("这部分还没写\n")

    # 爬头像，一人一行,爬好转置变成一天一行。
    data_final = headpic(inter)
    fast_export(data_final, r"amine\data.csv")

    # 生成config
    if fan_mode == "gain":
        enconfig(fast_import(r"data/temptate_gain.csv"), month)
    else:
        enconfig(fast_import(r"data/temptate_lost.csv"), month, len(ups))

    # 正确完成任务，保存本次运行的配置。
    export_config(config, config_dir)
